package GUIhelper;

public interface ErrorHandling {
    
    void handleAmtError(Exception e);

    void handleDateError(Exception e);
}
