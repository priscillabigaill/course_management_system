package model.data;

import model.Transaction;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;

public class DateFilter {

    private LocalDate startDate;
    private LocalDate endDate;

    public void setFilter(LocalDate startDate, LocalDate endDate) {
        this.startDate = startDate;
        this.endDate = endDate;
    }

    public List<Transaction> filterByDate(List<Transaction> transactions, LocalDate startDate, LocalDate endDate) {
        LocalDate fromDate = startDate;
        LocalDate toDate = endDate;

        Predicate<Transaction> dateFilter = isInFilter(fromDate, toDate);

        List<Transaction> filteredTransactions = new ArrayList<>();

        for (Transaction transaction : transactions) {
            if (dateFilter.test(transaction)) {
                filteredTransactions.add(transaction);
            }
        }
        return filteredTransactions;
    }

    private Predicate<Transaction> isInFilter(LocalDate fromDate, LocalDate toDate) {
        return transaction -> {
            // Assuming transaction.getDate() returns a String representation of a date
            String dateString = String.valueOf(transaction.getDate());
            LocalDate transactionDate = LocalDate.parse(dateString);
            return (transactionDate.isEqual(fromDate) || transactionDate.isAfter(fromDate))
                    && (transactionDate.isEqual(toDate) || transactionDate.isBefore(toDate));
        };
    }
}

