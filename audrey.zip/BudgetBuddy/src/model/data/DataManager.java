package model.data;

import model.Transaction;
import java.time.LocalDate;
import java.util.List;

public class DataManager {

    public DataManager(List<Transaction> loadedTransactions) {
        transactions = loadedTransactions; // Assign the loaded transactions to the transactions variable
        dateFilter = new DateFilter();
    }
    private List<Transaction> transactions;
    private DateFilter dateFilter;

    public List<Transaction> getFilteredTransactions(LocalDate startDate, LocalDate endDate) {
        List<Transaction> filteredTransactions = dateFilter.filterByDate(transactions, startDate, endDate);
        return filteredTransactions;
    }
}