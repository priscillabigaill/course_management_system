package model.category;

public class IncomeCategory extends Category {

    public IncomeCategory(String name) {
        super(name);
    }
    
}



