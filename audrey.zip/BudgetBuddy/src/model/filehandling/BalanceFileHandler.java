package model.filehandling;

import java.io.*;
import java.util.List;

public class BalanceFileHandler implements FileHandler<Integer> {
    private static final String BALANCE_FILE_PATH = "src/saved/balance.txt";

    @Override
    public void save(Integer balance) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(BALANCE_FILE_PATH))) {
            writer.write(String.valueOf(balance));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public Integer loadSingle() {
        try (BufferedReader reader = new BufferedReader(new FileReader(BALANCE_FILE_PATH))) {
            String line = reader.readLine();
            return Integer.parseInt(line.trim());
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public void save(List<Integer> items) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public List<Integer> load() {
        throw new UnsupportedOperationException("Not supported yet.");
    }
}



